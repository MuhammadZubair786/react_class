import logo from './logo.svg';
import './App.css';
import Home from './Components/Home';
import StepperForm from './Components/Stepper/mainstepper';

function App() {
  return (
   <StepperForm/>
  );
}

export default App;
